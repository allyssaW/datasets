Look for the full dataset? Please visit the [websit](http://jmcauley.ucsd.edu/data/amazon).
